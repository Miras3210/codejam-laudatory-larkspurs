"""Testing file."""


def hello() -> str:
    """Return hello world string."""
    return "Hello World!"


def main() -> None:
    """Initialize attachments.py."""
    print("attachment.py main")
    print(hello())
